.. cmake-module:: ../../Modules/TestBigEndian.cmake
