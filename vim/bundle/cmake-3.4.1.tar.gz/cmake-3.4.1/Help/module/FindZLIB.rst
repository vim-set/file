.. cmake-module:: ../../Modules/FindZLIB.cmake
